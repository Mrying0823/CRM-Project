/**
 * bs_pagination simple localization - RUSSIAN
 *
 * DO NOT CHANGE this file, as it will be overwritten in next update.
 * To use different values, write and use a similar structure js file.
 *
 */
var rsc_bs_pag = {
    go_to_page_title: 'На страницу',
    rows_per_page_title: 'Строк на странице',
    current_page_label: 'Страница',
    current_page_abbr_label: 'стр.',
    total_pages_label: 'из',
    total_pages_abbr_label: '/',
    total_rows_label: 'из',
    rows_info_records: 'записей',
    go_top_text: '&laquo;',
    go_prev_text: '&larr;',
    go_next_text: '&rarr;',
    go_last_text: '&raquo;'
};